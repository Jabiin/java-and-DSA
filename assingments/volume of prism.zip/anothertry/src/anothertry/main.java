package anothertry;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		  
	      Scanner s= new Scanner(System.in);
	        
	         System.out.println("Enter the area of base:");
	         double base=s.nextDouble();
	         System.out.println("Enter the height:");
	         double height=s.nextDouble();
	         
	 
	          
	          double  area=base*height ;
	      System.out.println("Volume Of Prism is: " + area);    
		
					
					
	}

}
