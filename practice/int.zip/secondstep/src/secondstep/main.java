package secondstep;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int friends = 100;
				friends = 1+100;
		System.out.println(friends);
	}

}
