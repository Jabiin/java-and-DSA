package anothertry;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		// && (and) both condition must be true
		// || (or) either condituon must be true
		// ! (not) reservs boolean value of condition 
		
		
		
		
					
					
	}

}
