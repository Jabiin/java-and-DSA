package anothertry;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		 float b=3,h =12,area ;  
         area = ( b*h) / 2 ;  
         System.out.println("Area of Triangle is: "+area);  
		
		
		
					
					
	}

}
