package anothertry;
import java.util.Scanner;
import java.util.jar.Attributes.Name;
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		// while loop 
		Scanner scanner = new Scanner(System.in);
		
		// the comdtion is to stop of someone tries to escape the name
		String name = "";
	while(name.isBlank()) {
		System.out.println("gali magacaaga");
		name = scanner.nextLine();
		
	}
		System.out.println("soo dhawaaw");
		
		
		
					
					
	}

}
