package anothertry;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String day = "axad";
		switch(day) {
		case "khamiis": System.out.println("waa maalinta");
		break;
		case "jimco": System.out.println("waa maalinta");
		break;
		
		case "sabti": System.out.println("waa maalinta");
		break;
		case "axad": System.out.println("waa maalinta");
		break;
		case "isniin": System.out.println("waa maalinta");
		break;
		case "talaado": System.out.println("waa maalinta");
		break;
		
	
		}
		
		
		
		
		
					
					
	}

}
