package anothertry;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int age = 20;
				if(age>=19) {
					System.out.println("grown ass");
				}
				 else if(age<20) {
					System.out.println("kid");
				}
				else {
					System.out.println("not good");
				}
					
					
					
					
	}

}
